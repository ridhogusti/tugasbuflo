This package contains of Codo Player Free system files. For setup instructions, go to codoplayer.com.

The use of software is based on GPL v3 license with additional special terms, found under www.codoplayer.com/policy/license/free.

Codo Player 
Copyright (C) Donato Software House